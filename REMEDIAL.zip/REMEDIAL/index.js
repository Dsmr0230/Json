const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mysql = require('mysql2/promise'); // Importamos la librería mysql2 con promesas
const app = express();
const port = 3000;

// Middleware para habilitar CORS (permite peticiones desde tu frontend)
app.use(cors());

// Middleware para parsear el cuerpo de las peticiones como JSON
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// **Configuración de la conexión a la base de datos MySQL**
const dbConfig = {
    host: '3306', // Cambia esto si tu servidor MySQL está en otro lugar
    user: 'root', // Reemplaza con tu nombre de usuario de MySQL
    password: '', // Reemplaza con tu contraseña de MySQL
    database: 'empleados' // Reemplaza con el nombre de tu base de datos
};

// Función para obtener una conexión a la base de datos
async function getConnection() {
    try {
        const connection = await mysql.createConnection(dbConfig);
        return connection;
    } catch (error) {
        console.error('Error al conectar a la base de datos:', error);
        throw error;
    }
}

// **Ruta para registrar un nuevo empleado (POST /register)**
app.post('/register', async (req, res) => {
    const { nombre, email, puesto, direccion } = req.body;
    if (!nombre || !email || !puesto || !direccion) {
        return res.status(400).send('Todos los campos son requeridos.');
    }

    let connection;
    try {
        connection = await getConnection();
        const [result] = await connection.execute(
            'INSERT INTO empleados (nombre, email, puesto, direccion) VALUES (?, ?, ?, ?)',
            [nombre, email, puesto, direccion]
        );
        res.send('Empleado registrado exitosamente.');
    } catch (error) {
        console.error('Error al registrar empleado:', error);
        res.status(500).send('Error al registrar el empleado en la base de datos.');
    } finally {
        if (connection) connection.end();
    }
});

// **Ruta para obtener todos los empleados (GET /empleados)**
app.get('/empleados', async (req, res) => {
    let connection;
    try {
        connection = await getConnection();
        const [rows] = await connection.execute('SELECT * FROM empleados');
        res.json(rows);
    } catch (error) {
        console.error('Error al obtener empleados:', error);
        res.status(500).send('Error al obtener los empleados de la base de datos.');
    } finally {
        if (connection) connection.end();
    }
});

// **Ruta para obtener un empleado por ID (GET /empleados/:id)**
app.get('/empleados/:id', async (req, res) => {
    const id = parseInt(req.params.id);
    let connection;
    try {
        connection = await getConnection();
        const [rows] = await connection.execute('SELECT * FROM empleados WHERE id = ?', [id]);
        if (rows.length > 0) {
            res.json(rows[0]);
        } else {
            res.status(404).send('Empleado no encontrado.');
        }
    } catch (error) {
        console.error('Error al obtener empleado:', error);
        res.status(500).send('Error al obtener el empleado de la base de datos.');
    } finally {
        if (connection) connection.end();
    }
});

// **Ruta para actualizar un empleado por ID (PUT /empleados/:id)**
app.put('/empleados/:id', async (req, res) => {
    const id = parseInt(req.params.id);
    const { nombre, email, puesto, direccion } = req.body;
    let connection;
    try {
        connection = await getConnection();
        const [result] = await connection.execute(
            'UPDATE empleados SET nombre = ?, email = ?, puesto = ?, direccion = ? WHERE id = ?',
            [nombre, email, puesto, direccion, id]
        );
        if (result.affectedRows > 0) {
            res.send('Empleado actualizado exitosamente.');
        } else {
            res.status(404).send('Empleado no encontrado.');
        }
    } catch (error) {
        console.error('Error al actualizar empleado:', error);
        res.status(500).send('Error al actualizar el empleado en la base de datos.');
    } finally {
        if (connection) connection.end();
    }
});

// **Ruta para eliminar un empleado por ID (DELETE /empleados/:id)**
app.delete('/empleados/:id', async (req, res) => {
    const id = parseInt(req.params.id);
    let connection;
    try {
        connection = await getConnection();
        const [result] = await connection.execute('DELETE FROM empleados WHERE id = ?', [id]);
        if (result.affectedRows > 0) {
            res.send('Empleado eliminado exitosamente.');
        } else {
            res.status(404).send('Empleado no encontrado.');
        }
    } catch (error) {
        console.error('Error al eliminar empleado:', error);
        res.status(500).send('Error al eliminar el empleado de la base de datos.');
    } finally {
        if (connection) connection.end();
    }
});

// Inicia el servidor
app.listen(port, () => {
    console.log(`Servidor escuchando en http://localhost:${port}`);
});