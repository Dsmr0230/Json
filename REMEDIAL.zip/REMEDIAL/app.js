const API_URL = "http://localhost:3000";

document.addEventListener('DOMContentLoaded', () => {
    cargarEmpleados();
});

document.getElementById('formEmpleado').addEventListener('submit', async (e) => {
    e.preventDefault();

    const id = document.getElementById('idEmpleado').value;
    const nombre = document.getElementById('nombre').value;
    const email = document.getElementById('email').value;
    const puesto = document.getElementById('puesto').value;
    const direccion = document.getElementById('direccion').value; // Nueva línea
    const data = { nombre, email, puesto, direccion }; // Dirección incluida

    const url = id ? `${API_URL}/empleados/${id}` : `${API_URL}/register`;
    const method = id ? 'PUT' : 'POST';

    try {
        const response = await fetch(url, {
            method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        if (!response.ok) {
            throw new Error(`Error en la petición: ${response.status} - ${response.statusText}`);
        }

        const result = await response.text();
        alert(result);
        document.getElementById('formEmpleado').reset();
        document.getElementById('idEmpleado').value = '';
        document.getElementById('btnSubmit').textContent = 'Registrar';
        cargarEmpleados();
    } catch (error) {
        console.error('Error al enviar la petición:', error);
        alert("Hubo un problema al procesar la solicitud.");
    }
});

async function cargarEmpleados() {
    try {
        const response = await fetch(`${API_URL}/empleados`);
        if (!response.ok) {
            throw new Error('Error al cargar empleados');
        }
        const empleados = await response.json();
        mostrarEmpleados(empleados);
    } catch (error) {
        console.error('Error:', error);
    }
}

function mostrarEmpleados(empleados) {
    const tabla = document.getElementById('tablaRegistros');
    tabla.innerHTML = '';

    empleados.forEach(empleado => {
        const fila = document.createElement('tr');
        fila.innerHTML = `
            <td>${empleado.id}</td>
            <td>${empleado.nombre}</td>
            <td>${empleado.email}</td>
            <td>${empleado.puesto}</td>
            <td>${empleado.direccion}</td>
            <td>
                <button class="btn btn-sm btn-warning me-2" onclick="editarEmpleado(${empleado.id})">
                    <i class="bi bi-pencil"></i> Editar
                </button>
                <button class="btn btn-sm btn-danger" onclick="eliminarEmpleado(${empleado.id})">
                    <i class="bi bi-trash"></i> Eliminar
                </button>
            </td>
        `;
        tabla.appendChild(fila);
    });
}

async function editarEmpleado(id) {
    try {
        const response = await fetch(`${API_URL}/empleados/${id}`);
        if (!response.ok) {
            throw new Error('Error al obtener empleado');
        }
        const empleado = await response.json();

        document.getElementById('idEmpleado').value = empleado.id;
        document.getElementById('nombre').value = empleado.nombre;
        document.getElementById('email').value = empleado.email;
        document.getElementById('puesto').value = empleado.puesto;
        document.getElementById('direccion').value = empleado.direccion; // Nueva línea
        document.getElementById('btnSubmit').textContent = 'Actualizar';

        window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error) {
        console.error('Error:', error);
        alert('Error al cargar datos del empleado');
    }
}

async function eliminarEmpleado(id) {
    if (!confirm('¿Estás seguro de que quieres eliminar este empleado?')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/empleados/${id}`, {
            method: 'DELETE'
        });

        if (!response.ok) {
            throw new Error('Error al eliminar empleado');
        }

        const result = await response.text();
        alert(result);
        cargarEmpleados();
    } catch (error) {
        console.error('Error:', error);
        alert('Error al eliminar empleado');
    }
}